"""Observable scope/ranking invariants, independent of reference answers."""

import ast
import math
import re
from typing import Any

from openpyxl.utils import coordinate_to_tuple, get_column_letter, range_boundaries

from .executor import ISO_DATE, ExecutionResult, stored_datetime
from .postprocessor import format_answer


def canonical_label(value: Any) -> str:
    return " ".join(re.sub(r"(?<=[A-Za-z])-\s*\n\s*(?=[a-z])", "", str(value)).split())


def cell_region(sheet: dict[str, Any], row: int, col: int) -> dict[str, Any] | None:
    matches = [
        table
        for table in sheet.get("tables", [])
        if (bounds := range_boundaries(table["range"]))[0] <= col <= bounds[2]
        and bounds[1] <= row <= bounds[3]
    ]
    return matches[0] if len(matches) == 1 else None


def source_headers(sheet: dict[str, Any], address: str) -> dict[str, list[str]]:
    row, col = coordinate_to_tuple(address)
    table = cell_region(sheet, row, col)
    return (table.get("headers") if table else None) or sheet.get("headers", {})


def read_header_paths(
    sheet: dict[str, Any], addresses: list[str]
) -> dict[str, list[str]]:
    headers: dict[str, list[str]] = {}
    seen: set[str | None] = set()
    for address in addresses:
        table = cell_region(sheet, *coordinate_to_tuple(address))
        key = table["range"] if table else None
        if key in seen:
            continue
        seen.add(key)
        for col, path in source_headers(sheet, address).items():
            headers.setdefault(col, []).extend(
                value for value in path if value not in headers.get(col, [])
            )
    return headers


def row_label_index(sheet: dict[str, Any]) -> dict[int, list[tuple[int, str]]]:
    result: dict[int, list[tuple[int, str]]] = {}
    for address, entry in sheet["cells"].items():
        if entry["kind"] == "string" and entry["value"]:
            row, col = coordinate_to_tuple(address)
            result.setdefault(row, []).append((col, canonical_label(entry["value"])))
    return result


def labels_before(
    sheet: dict[str, Any],
    row: int,
    col: int,
    index: dict[int, list[tuple[int, str]]],
) -> list[str]:
    table = cell_region(sheet, row, col)
    left = range_boundaries(table["range"])[0] if table else 1
    return [text for position, text in index.get(row, []) if left <= position < col]


def age_reference_columns(sheet: dict[str, Any], query: str) -> tuple[str, str] | None:
    """An explicitly named reference date wins over the Admission default."""
    if not re.search(r"\b(oldest|youngest)\b", query, re.IGNORECASE):
        return None
    if re.search(
        r"\b(?:as of|on)\s+\d{4}[-/]\d|\bby (?:the )?(?:birth date|date of birth)|\bbased on (?:the )?(?:birth date|date of birth)",
        query,
        re.IGNORECASE,
    ):
        return None
    date_columns = {
        get_column_letter(coordinate_to_tuple(address)[1])
        for address, entry in sheet["cells"].items()
        if entry["kind"] == "datetime"
        or entry["kind"] == "string"
        and ISO_DATE.fullmatch(str(entry["value"]).strip())
    }
    headers = sheet.get("headers", {})
    birth = [
        col
        for col, path in headers.items()
        if col in date_columns
        and any(re.search(r"birth|dob", value, re.IGNORECASE) for value in path)
    ]
    if len(birth) != 1:
        return None
    references = {}
    for col in date_columns - {birth[0]}:
        label = " ".join(headers.get(col, []))
        label = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", label).lower()
        tokens = set(re.findall(r"[a-z]+", label)) - {
            "date",
            "of",
            "on",
            "at",
            "the",
            "time",
            "year",
        }
        if tokens:
            references[col] = tokens
    contextual = [
        col
        for col, tokens in references.items()
        if any(
            re.search(
                rf"\b(?:at|on|relative to|with respect to)\b[^.?!]{{0,45}}\b{re.escape(token)}\b",
                query,
                re.IGNORECASE,
            )
            for token in tokens
        )
    ]
    mentioned = [
        col
        for col, tokens in references.items()
        if any(
            re.search(rf"\b{re.escape(token)}\b", query, re.IGNORECASE)
            for token in tokens
        )
    ]
    choices = contextual or mentioned
    if len(choices) == 1:
        return birth[0], choices[0]
    if choices:
        return None
    admission = [col for col, tokens in references.items() if "admission" in tokens]
    return (birth[0], admission[0]) if len(admission) == 1 else None


def latest_reference_columns(
    sheet: dict[str, Any], query: str
) -> tuple[str, str] | None:
    """Offer an exact helper binding only for uniquely named entity/time headers."""
    if (
        not re.search(r"\blatest\b", query, re.IGNORECASE)
        or len(sheet.get("tables", [])) > 1
    ):
        return None
    keys = []
    dates = {
        get_column_letter(coordinate_to_tuple(address)[1])
        for address, entry in sheet["cells"].items()
        if entry["kind"] == "datetime"
        or entry["kind"] == "string"
        and ISO_DATE.fullmatch(str(entry["value"]).strip())
    }
    times = []
    for column, path in sheet.get("headers", {}).items():
        if not path:
            continue
        leaf = canonical_label(path[-1])
        if re.search(
            rf"\b(?:each|every|per)\s+{re.escape(leaf)}\b", query, re.IGNORECASE
        ):
            keys.append(column)
        if column in dates and re.search(
            rf"(?<!\w){re.escape(leaf)}(?!\w)", query, re.IGNORECASE
        ):
            times.append(column)
    if not times and len(dates) == 1:
        times = list(dates)
    return (
        (keys[0], times[0])
        if len(keys) == 1 and len(times) == 1 and keys[0] != times[0]
        else None
    )


def date_field_errors(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """A direct date answer must read the uniquely named date field, when observable."""
    values = (
        execution.result if isinstance(execution.result, list) else [execution.result]
    )
    if not values or not all(
        isinstance(value, str) and ISO_DATE.fullmatch(value.strip()) for value in values
    ):
        return []

    def words(text: str) -> set[str]:
        text = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", text).lower()
        return {
            "birth" if word == "dob" else word for word in re.findall(r"[a-z]+", text)
        } - {
            "date",
            "time",
            "timestamp",
            "iso",
            "text",
            "datetime",
            "of",
            "the",
            "on",
            "at",
            "yyyy",
            "mm",
            "dd",
        }

    requested = words(query)
    for name, sheet in workbook.items():
        reads = {
            key.rsplit("!", 1)[1]: entry
            for key, entry in execution.reads.items()
            if key.rsplit("!", 1)[0] == name
            and entry["kind"] not in {"lookup_probe", "type_probe"}
        }
        date_reads = [
            address
            for address, entry in reads.items()
            if entry["kind"] == "datetime"
            or entry["kind"] == "string"
            and ISO_DATE.fullmatch(str(entry["value"]).strip())
        ]
        if not date_reads:
            continue
        headers = read_header_paths(sheet, date_reads)
        date_columns = {
            get_column_letter(coordinate_to_tuple(address)[1])
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "datetime"
            or entry["kind"] == "string"
            and ISO_DATE.fullmatch(str(entry["value"]).strip())
        }
        matches = [
            column
            for column in date_columns
            if words(" ".join(headers.get(column, []))) & requested
        ]
        if len(matches) == 1 and not any(
            get_column_letter(coordinate_to_tuple(address)[1]) == matches[0]
            for address in date_reads
        ):
            return [
                f"Date field mismatch: question names the date header in {name!r} column {matches[0]}, but only different date fields were read. Read the requested date field from the selected record; do not substitute admission/birth/another date."
            ]
    return []


def column_scope_errors(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """Explicitly named numeric header categories must all be evidenced in a comparison."""
    errors = column_year_errors(workbook, execution, query)
    if not re.search(
        r"\b(?:and|or|than|versus|vs|compare|difference|sum|combined)\b",
        query,
        re.IGNORECASE,
    ):
        return errors
    for name, sheet in workbook.items():
        numeric = [
            key.rsplit("!", 1)[1]
            for key, entry in execution.reads.items()
            if key.rsplit("!", 1)[0] == name and entry["kind"] == "number"
        ]
        if not numeric:
            continue
        headers = read_header_paths(sheet, numeric)
        numeric_columns = {
            get_column_letter(coordinate_to_tuple(address)[1])
            for address, entry in sheet["cells"].items()
            if entry["kind"] in {"number", "uncached_formula"}
        }
        named: dict[str, set[str]] = {}
        contexts: dict[str, set[tuple[str, ...]]] = {}
        for column, path in headers.items():
            if column not in numeric_columns or not path:
                continue
            for index, raw_label in enumerate(path):
                label = canonical_label(raw_label)
                if sum(character.isalpha() for character in label) < 3:
                    continue
                if re.search(rf"(?<!\w){re.escape(label)}(?!\w)", query, re.IGNORECASE):
                    named.setdefault(label, set()).add(column)
                    contexts.setdefault(label, set()).add(tuple(path[: index + 1]))
        targets = {
            label: columns
            for label, columns in named.items()
            if len(contexts[label]) == 1
        }
        observed = {
            get_column_letter(coordinate_to_tuple(address)[1]) for address in numeric
        }
        # A shared parent is a valid requested branch even when its Total and
        # child columns all inherit the caption. Repeated captions under
        # competing ancestry remain ambiguous. Nested aliases alone do not
        # establish a two-category comparison.
        disjoint = any(
            left.isdisjoint(right)
            for i, left in enumerate(targets.values())
            for right in list(targets.values())[i + 1 :]
        )
        if disjoint and any(not columns & observed for columns in targets.values()):
            missing = {
                label: sorted(columns)
                for label, columns in targets.items()
                if not columns & observed
            }
            return errors + [
                f"Named column coverage mismatch in {name!r}: requested numeric headers {missing!r} were not read. Use exact complete header paths rather than neighboring columns."
            ]
    return errors


def column_year_errors(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """A literal requested reporting year must occur in the selected header branch."""
    years = set(re.findall(r"\b(?:19|20)\d{2}\b", query))
    if (
        len(years) != 1
        or not re.search(
            rf"\b(?:in|for|during|year|period)\s+{next(iter(years))}\b(?!-\d)",
            query,
            re.IGNORECASE,
        )
        or re.search(
            r"\b(?:forecast|predict|project|estimate|previous|prior|preceding|next|following|earlier|later)\w*\b",
            query,
            re.IGNORECASE,
        )
    ):
        return []
    year = next(iter(years))
    errors: list[str] = []
    for name, sheet in workbook.items():
        regions: dict[str | None, list[str]] = {}
        for key, entry in execution.reads.items():
            if key.rsplit("!", 1)[0] == name and entry["kind"] == "number":
                address = key.rsplit("!", 1)[1]
                region = cell_region(sheet, *coordinate_to_tuple(address))
                regions.setdefault(region["range"] if region else None, []).append(
                    address
                )
        for addresses in regions.values():
            headers = source_headers(sheet, addresses[0])
            header_years = {
                column: set(re.findall(r"\b(?:19|20)\d{2}\b", " ".join(path)))
                for column, path in headers.items()
            }
            matching = {
                column for column, values in header_years.items() if values == {year}
            }
            selected = {
                get_column_letter(coordinate_to_tuple(address)[1])
                for address in addresses
            }
            # Missing/ambiguous year metadata cannot prove a contradiction. A
            # correctly selected target-year column may also need prior inputs.
            if (
                matching
                and not selected & matching
                and all(
                    len(header_years.get(column, set())) == 1 for column in selected
                )
            ):
                errors.append(
                    f"Requested reporting year {year} is absent from numeric reads in {name!r}; "
                    f"selected columns {sorted(selected)}, target-year columns {sorted(matching)}. Use the complete year/measure header path."
                )
    return errors


def row_scope_errors(
    workbook: dict[str, Any], reads: dict[str, Any], query: str
) -> list[str]:
    errors = []
    ranges = re.findall(r"\b(\d+)\s*(?:to|[-–])\s*(\d+)\b", query.lower())
    for name, sheet in workbook.items():
        selected = [
            (coordinate_to_tuple(key[len(name) + 1 :]), entry)
            for key, entry in reads.items()
            if key.startswith(name + "!")
            and re.fullmatch(r"[A-Z]+[1-9]\d*", key[len(name) + 1 :])
        ]
        numeric_rows = {
            position[0] for position, entry in selected if entry["kind"] == "number"
        }
        data_rows = {
            coordinate_to_tuple(address)[0]
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "number"
        }
        for lower, upper in ranges:
            pattern = rf"\b{lower}\s*(?:to|[-–])\s*{upper}\b"
            matching = {
                coordinate_to_tuple(address)[0]
                for address, entry in sheet["cells"].items()
                if entry["kind"] == "string"
                and coordinate_to_tuple(address)[0] in data_rows
                and re.search(pattern, str(entry["value"]), re.IGNORECASE)
            }
            if matching and numeric_rows and not numeric_rows & matching:
                errors.append(
                    f"Numeric reads omit the requested row range {lower} to {upper} in {name}; matching rows: {sorted(matching)}"
                )

        numeric_columns_by_row: dict[int, list[int]] = {}
        for address, entry in sheet["cells"].items():
            if entry["kind"] == "number":
                row, col = coordinate_to_tuple(address)
                numeric_columns_by_row.setdefault(row, []).append(col)
        leading_labels = []
        for address, entry in sheet["cells"].items():
            if entry["kind"] == "string" and entry["value"]:
                row, col = coordinate_to_tuple(address)
                if any(other > col for other in numeric_columns_by_row.get(row, [])):
                    leading_labels.append(((row, col), canonical_label(entry["value"])))
        # Both explicitly named measures must be read for a difference. Searching
        # labels alone is not evidence that their numeric operands were selected.
        if re.search(r"\bdifference between\b", query, re.IGNORECASE):
            lower = canonical_label(query).casefold()
            named: dict[str, set[int]] = {}
            for (row, _), label in leading_labels:
                text = label.casefold()
                if len(re.findall(r"\w+", text)) >= 2 and re.search(
                    rf"(?<!\w){re.escape(text)}(?!\w)", lower
                ):
                    named.setdefault(text, set()).add(row)
            maximal = {
                label: matches
                for label, matches in named.items()
                if not any(label != other and label in other for other in named)
            }
            if len(maximal) >= 2:
                for label, matches in maximal.items():
                    if not matches & numeric_rows:
                        errors.append(
                            f"Difference operands omit explicitly requested row measure {label!r}; read its numeric value in the requested section, not a neighboring metric."
                        )
        # Across ALL displayed categories is a column-coverage contract when the
        # metric is a row label. Explicit leaf/weighted qualifiers override it.
        if re.search(
            r"\b(?:average|mean)\b.*\bacross all\b", query, re.IGNORECASE
        ) and not re.search(
            r"\b(?:leaf|mutually exclusive|weighted)\b", query, re.IGNORECASE
        ):
            for row in numeric_rows:
                if any(
                    position[0] == row and label.casefold() in query.casefold()
                    for position, label in leading_labels
                ):
                    available = set(mean_scope_cells(sheet, row, query) or [])
                    observed = {
                        key[len(name) + 1 :]
                        for key, entry in reads.items()
                        if key.startswith(name + "!") and entry["kind"] == "number"
                    }
                    if available - observed:
                        errors.append(
                            f"Average across all displayed categories omitted cells {sorted(available - observed)}. Include all displayed data columns, including parent Totals, unless the question explicitly restricts to leaves/weighted averaging."
                        )
        options = re.search(
            r"rank the following [^:]+:\s*(.*?)\.\s*answer", query, re.IGNORECASE
        )
        if options:
            for option in options[1].split(","):
                text = re.sub(
                    r"^and\s+", "", option.strip(), flags=re.IGNORECASE
                ).casefold()
                matching = {
                    position[0]
                    for position, label in leading_labels
                    if label.casefold() == text
                    or label.casefold().startswith(text + " ")
                }
                if matching and not numeric_rows & matching:
                    errors.append(
                        f"Ranking reads omit the requested option {option.strip()!r}; use find_rows() to locate each label separately, not adjacent row assumptions."
                    )
    return errors + all_category_column_errors(workbook, reads, query)


def ranked_label_binding_errors(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """Check direct numeric rankings against uniquely bound source row labels."""
    if not re.search(r"\b(?:rank|sort)\b", query, re.IGNORECASE):
        return []
    result = execution.result
    if (
        not isinstance(result, list)
        or len(result) < 2
        or not all(isinstance(item, str) for item in result)
    ):
        return []
    labels = [canonical_label(item).casefold() for item in result]
    if len(set(labels)) != len(labels):
        return []
    directions = []
    if re.search(r"\bdescending\b", query, re.IGNORECASE):
        directions.append(True)
    if re.search(r"\bascending\b", query, re.IGNORECASE):
        directions.append(False)
    if len(directions) != 1:
        return []
    reverse = directions[0]
    candidates: list[list[tuple[str, float]]] = []
    for name, sheet in workbook.items():
        index = row_label_index(sheet)
        columns: dict[int, list[tuple[str, dict[str, Any]]]] = {}
        for key, entry in execution.reads.items():
            if key.rsplit("!", 1)[0] == name and entry["kind"] == "number":
                address = key.rsplit("!", 1)[1]
                columns.setdefault(coordinate_to_tuple(address)[1], []).append(
                    (address, entry)
                )
        for column, entries in columns.items():
            if len(entries) != len(labels):
                continue
            matches: dict[str, list[tuple[str, float]]] = {
                label: [] for label in labels
            }
            for address, entry in entries:
                row = coordinate_to_tuple(address)[0]
                captions = [
                    text.casefold() for text in labels_before(sheet, row, column, index)
                ]
                for label in labels:
                    if any(
                        text == label or text.startswith(label + " ")
                        for text in captions
                    ):
                        matches[label].append((f"{name}!{address}", entry["value"]))
            if all(len(matches[label]) == 1 for label in labels):
                bound = [matches[label][0] for label in labels]
                if len({address for address, _ in bound}) == len(labels):
                    candidates.append(bound)
    # Repeated labels, multiple measures or transformed sorting keys are
    # ambiguous. Only validate a unique direct measure, never infer a new one.
    if len(candidates) != 1:
        return []
    bound = candidates[0]
    values = [value for _, value in bound]
    if not any(
        record.get("reverse") == reverse
        and all(type(key) in {int, float} for key in record["keys"])
        and sorted(record["keys"]) == sorted(values)
        for record in execution.sorts
    ):
        return []
    if values == sorted(values, reverse=reverse):
        return []
    return [
        (
            f"Ranked labels are not paired with their source row measures: {list(zip(result, bound))}. "
            "Look up each option's own row and keep its label/value pair together when sorting; "
            "a parallel list of literal labels can silently attach values to different rows."
        )
    ]


def all_category_column_errors(
    workbook: dict[str, Any], reads: dict[str, Any], query: str
) -> list[str]:
    """Flag missing siblings only in an unambiguous, homogeneous across-all branch."""
    if not re.search(r"\bacross all\b", query, re.IGNORECASE) or re.search(
        r"\b(?:average|mean|weighted|leaf|leaves|except|exclude|excluding|ignore)\b|\bpublished total\b",
        query,
        re.IGNORECASE,
    ):
        return []
    errors: list[str] = []
    for name, sheet in workbook.items():
        observed = {
            key[len(name) + 1 :]
            for key, entry in reads.items()
            if key.startswith(name + "!") and entry["kind"] == "number"
        }
        for row in {coordinate_to_tuple(address)[0] for address in observed}:
            selected = [
                address
                for address in observed
                if coordinate_to_tuple(address)[0] == row
            ]
            region = cell_region(sheet, *coordinate_to_tuple(selected[0]))
            if region is None:
                continue
            bounds = range_boundaries(region["range"])
            available = [
                address
                for address, entry in sheet["cells"].items()
                if entry["kind"] == "number"
                and (pos := coordinate_to_tuple(address))[0] == row
                and bounds[0] <= pos[1] <= bounds[2]
            ]
            paths = {
                address: region.get("headers", {}).get(
                    get_column_letter(coordinate_to_tuple(address)[1]), []
                )
                for address in available
            }
            if len(paths) < 2 or any(len(path) < 2 for path in paths.values()):
                continue
            if len({tuple(path[:-1]) for path in paths.values()}) != 1:
                continue
            if (
                len(
                    {
                        sheet["cells"][address].get("number_format", "General")
                        for address in available
                    }
                )
                != 1
            ):
                continue
            if any(
                re.search(
                    r"\b(?:total|all|id|identifier|code|weight|denominator)\b|sample size",
                    path[-1],
                    re.IGNORECASE,
                )
                for path in paths.values()
            ):
                continue
            # Explicit category names can narrow an across-all population; such
            # mixed row/column scope needs model interpretation, not this guard.
            stopwords = {
                "the",
                "and",
                "for",
                "all",
                "total",
                "published",
                "value",
                "values",
                "number",
                "numbers",
                "column",
                "columns",
            }
            query_words = set(re.findall(r"[a-z]{3,}", query.casefold())) - stopwords
            if any(
                query_words & set(re.findall(r"[a-z]{3,}", path[-1].casefold()))
                for path in paths.values()
            ):
                continue
            missing = set(available) - observed
            if missing:
                errors.append(
                    f"Across-all selection omits sibling category cells in {name}: {sorted(missing)}. "
                    "Inspect the complete shared header branch before aggregating or comparing rows; do not silently drop a category."
                )
    return errors


def age_sort_errors(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """Audit elapsed-age order/index without computing a reference answer."""
    lower = query.lower()
    for name, sheet in workbook.items():
        reference = age_reference_columns(sheet, query)
        if reference is None:
            continue
        birth_col, reference_col = reference
        ages = []
        for key, entry in execution.reads.items():
            if key.startswith(name + "!") and (
                entry["kind"] == "datetime"
                or entry["kind"] == "string"
                and ISO_DATE.fullmatch(str(entry["value"]).strip())
            ):
                row, col = coordinate_to_tuple(key[len(name) + 1 :])
                if get_column_letter(col) != birth_col:
                    continue
                other = execution.reads.get(f"{name}!{reference_col}{row}")
                if other and (
                    other["kind"] == "datetime"
                    or other["kind"] == "string"
                    and ISO_DATE.fullmatch(str(other["value"]).strip())
                ):
                    ages.append(
                        (
                            stored_datetime(other["value"])
                            - stored_datetime(entry["value"])
                        ).total_seconds()
                        / 86400
                    )
        words = {
            "first": 1,
            "second": 2,
            "third": 3,
            "fourth": 4,
            "fifth": 5,
            "sixth": 6,
            "one": 1,
            "two": 2,
            "three": 3,
            "four": 4,
            "five": 5,
            "six": 6,
            "seven": 7,
            "eight": 8,
            "nine": 9,
            "ten": 10,
        }
        ordinal = re.search(
            r"\b(first|second|third|fourth|fifth|sixth)[ -](oldest|youngest)\b", lower
        )
        group = re.search(
            r"among (?:the )?(\d+|one|two|three|four|five|six|seven|eight|nine|ten) (oldest|youngest)",
            lower,
        )
        count = (
            int(group[1])
            if group and group[1].isdigit()
            else words[group[1]]
            if group
            else words[ordinal[1]]
            if ordinal
            else 1
        )
        oldest = "oldest" in lower
        for record in execution.sorts:
            keys = record["keys"]
            if (
                not keys
                or not ages
                or not all(isinstance(value, (int, float)) for value in keys)
            ):
                continue
            sign = (
                1
                if sorted(keys) == sorted(ages)
                else -1
                if sorted(keys) == sorted(-age for age in ages)
                else 0
            )
            if not sign:
                continue
            descending_age = bool(record["reverse"]) == (sign == 1)
            expected = (
                list(range(count))
                if descending_age == oldest
                else list(range(len(keys) - count, len(keys)))
            )
            expected_index = (
                count - 1 if descending_age == oldest else len(keys) - count
            )
            for selection in record["selected"]:
                if (
                    isinstance(selection, int)
                    and not group
                    and selection != expected_index
                ):
                    return [
                        "Elapsed-age sort direction/index contradicts the requested rank. Oldest means LARGEST elapsed days; youngest means SMALLEST. Correct reverse and the selected index."
                    ]
                if (
                    isinstance(selection, list)
                    and group
                    and sorted(selection) != expected
                ):
                    return [
                        "Selected age slice does not contain the requested youngest/oldest group. Correct the elapsed-age sort direction and slice."
                    ]
    return []


def label_errors(
    execution: ExecutionResult, query: str, workbook: dict[str, Any] | None = None
) -> list[str]:
    requested = re.search(
        r"answer with only (?:the )?(.*(?:name|category))\b", query, re.IGNORECASE
    )
    if isinstance(execution.result, (int, float)) and requested and workbook:

        def tokens(text: str) -> set[str]:
            text = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", text)
            return {
                word.rstrip("s") for word in re.findall(r"[a-z]+", text.casefold())
            } - {"of", "the", "only", "with", "answer"}

        identity = tokens(requested[1])
        if "name" in identity:
            identity = {"name"}
        for key, entry in execution.reads.items():
            if entry["kind"] != "number" or entry["value"] != execution.result:
                continue
            name, address = key.rsplit("!", 1)
            sheet = workbook[name]
            row, column = coordinate_to_tuple(address)
            headers = source_headers(sheet, address)
            own = headers.get(get_column_letter(column), [])
            if own and identity & tokens(own[-1]):
                return []  # Numeric identifiers/categories are legitimate labels.
            for position, text in row_label_index(sheet).get(row, []):
                path = headers.get(get_column_letter(position), [])
                if position < column and path and identity & tokens(path[-1]):
                    return [
                        "The question requests a name/category, but the result is a numeric measure. Return the complete corresponding identity cell, not its score or percentage."
                    ]
    if (
        not isinstance(execution.result, str)
        or not re.search(
            r"answer with only (?:the )?.*(?:name|category)\b", query, re.IGNORECASE
        )
        or "full name" in query.lower()
    ):
        return []
    labels = {
        canonical_label(entry["value"])
        for entry in execution.reads.values()
        if entry["kind"] == "string"
    }
    if canonical_label(execution.result) not in labels:
        return [
            "Final label does not match a whole selected workbook label. Do not index a scalar string to obtain a name; use cell(), or a complete element from values()."
        ]
    if re.search(r"\bhour category\b", query, re.IGNORECASE) and re.match(
        r"^(?:Total\b|All\b)", execution.result, re.IGNORECASE
    ):
        return [
            "A Total/All row aggregates hour categories; the question asks for a specific hour category. Exclude the grand total from candidate rows."
        ]
    return []


def complete_category_contract(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> str | None:
    """Audit an unrestricted category extremum against its observed eligible rows."""
    if (
        not isinstance(execution.result, str)
        or not re.search(
            r"\bwhich\b.*\bcategory\b.*\b(highest|largest|lowest|smallest)\b",
            query,
            re.IGNORECASE,
        )
        or re.search(
            r"\b(?:among|only|excluding|except|leaf|leaves|mutually exclusive|before|after)\b|\d+\s*(?:to|[-–])\s*\d+",
            query.split("?")[0],
            re.IGNORECASE,
        )
    ):
        return None
    smallest = bool(re.search(r"\b(?:lowest|smallest)\b", query, re.IGNORECASE))
    candidates = []
    for name, sheet in workbook.items():
        observed = [
            (key.rsplit("!", 1)[1], entry)
            for key, entry in execution.reads.items()
            if key.startswith(name + "!") and entry["kind"] == "number"
        ]
        columns = {coordinate_to_tuple(address)[1] for address, _ in observed}
        areas = {
            region["range"]
            if (region := cell_region(sheet, *coordinate_to_tuple(address)))
            else None
            for address, _ in observed
        }
        if len(columns) != 1 or len(areas) != 1 or None in areas:
            continue
        # An unrestricted extremum cannot silently skip an intermediate category
        # within the observed table span. Only fill existing numeric cells in the
        # same table/column; explicit restricted queries were excluded above.
        column = next(iter(columns))
        low, high = (
            min(coordinate_to_tuple(address)[0] for address, _ in observed),
            max(coordinate_to_tuple(address)[0] for address, _ in observed),
        )
        region = cell_region(sheet, *coordinate_to_tuple(observed[0][0]))
        observed = [
            (address, entry)
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "number"
            and (position := coordinate_to_tuple(address))[1] == column
            and low <= position[0] <= high
            and cell_region(sheet, *position) == region
        ]
        labels = row_label_index(sheet)
        label_counts: dict[str, int] = {}
        for row_labels in labels.values():
            for _, text in row_labels:
                label_counts[text] = label_counts.get(text, 0) + 1
        choices = []
        for address, entry in observed:
            row, col = coordinate_to_tuple(address)
            leading = [
                (position, text)
                for position, text in labels.get(row, [])
                if position < col
            ]
            if len(leading) != 1:
                continue
            label_col, text = leading[0]
            if re.match(r"^(?:Total|All)\b", text, re.IGNORECASE):
                continue
            # A declared section is required when labels repeat across groups.
            if label_counts[text] != 1:
                return None
            choices.append(
                (entry["value"], f"{get_column_letter(label_col)}{row}", text, address)
            )
        if len(choices) < 2:
            continue
        best = (min if smallest else max)(value for value, _, _, _ in choices)
        winners = [
            (address, text) for value, address, text, _ in choices if value == best
        ]
        if len(winners) != 1:
            continue  # Tie policy belongs to the question; never invent one.
        address, text = winners[0]
        if canonical_label(execution.result) != text:
            candidates.append(
                (name, [(measure, label) for _, label, _, measure in choices])
            )
    if len(candidates) != 1:
        return None
    name, coordinates = candidates[0]
    operation = "min" if smallest else "max"
    return (
        f"category_values=[(num({name!r}, measure), cell({name!r}, label)) "
        f"for measure, label in {coordinates!r}]\n"
        f"result={operation}(category_values,key=lambda pair:pair[0])[1]"
    )


def entity_label_errors(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """Named row entities must come from their identity field, not a measure header."""
    match = re.search(r"answer with only (?:the )?(\w+) name", query, re.IGNORECASE)
    if not match or not isinstance(execution.result, (str, int, float)):
        return []
    term = match[1].casefold()
    for name, sheet in workbook.items():
        selected = [
            key[len(name) + 1 :]
            for key, entry in execution.reads.items()
            if key.startswith(name + "!") and entry["kind"] != "type_probe"
        ]
        if not selected:
            continue
        headers = read_header_paths(sheet, selected)
        selected_areas = {
            table["range"]
            if (table := cell_region(sheet, *coordinate_to_tuple(address)))
            else None
            for address in selected
        }
        columns = {
            column
            for column, path in headers.items()
            if any(
                re.search(rf"\b{re.escape(term)}\b", label, re.IGNORECASE)
                and len(label.split()) <= 3
                and not re.search(r"[,/]|\band\b", label, re.IGNORECASE)
                for label in path
            )
        }
        if not columns:
            continue
        number_rows = {
            coordinate_to_tuple(address)[0]
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "number"
        }
        labels = {
            canonical_label(entry["value"])
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "string"
            and get_column_letter(coordinate_to_tuple(address)[1]) in columns
            and coordinate_to_tuple(address)[0] in number_rows
            and (
                not sheet.get("tables")
                or (
                    (
                        table["range"]
                        if (table := cell_region(sheet, *coordinate_to_tuple(address)))
                        else None
                    )
                    in selected_areas
                )
            )
        }
        if labels and canonical_label(execution.result) not in labels:
            return [
                "Requested entity name must come from the identity column's data rows, not a numeric measure header or table title."
            ]
    return []


def aggregation_overlap_errors(
    workbook: dict[str, Any], reads: dict[str, Any], query: str
) -> list[str]:
    """Across-all sums must not combine a published parent with its children."""
    if not re.search(
        r"\b(?:sum|total|combined)\b", query, re.IGNORECASE
    ) or not re.search(r"\bacross all\b|\ball age groups\b", query, re.IGNORECASE):
        return []
    if re.search(
        r"\b(?:average|mean|difference|change|compare|percentage|ratio|share)\b|yes or no",
        query,
        re.IGNORECASE,
    ):
        return []
    for name, sheet in workbook.items():
        coordinates = [
            coordinate_to_tuple(key[len(name) + 1 :])
            for key, entry in reads.items()
            if key.startswith(name + "!") and entry["kind"] == "number"
        ]
        number_rows = {
            coordinate_to_tuple(address)[0]
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "number"
        }
        row_labels = row_label_index(sheet)
        intervals = []
        for row, col in coordinates:
            for text in labels_before(sheet, row, col, row_labels):
                interval = age_interval(text)
                if interval is not None:
                    intervals.append((row, col, interval))
        for index, (row, col, interval) in enumerate(intervals):
            for other_row, other_col, other in intervals[index + 1 :]:
                if (
                    row != other_row
                    and col == other_col
                    and cell_region(sheet, row, col)
                    == cell_region(sheet, other_row, col)
                    and max(interval[0], other[0]) <= min(interval[1], other[1])
                ):
                    return [
                        (
                            "Across-all age aggregation includes overlapping age intervals. "
                            "Use the matching published total, or a disjoint partition; "
                            "a broad age band and its narrower bands cannot both be summed."
                        )
                    ]
        boundaries = set()
        for address, entry in sheet["cells"].items():
            if entry["kind"] == "string" and entry["value"]:
                row, _ = coordinate_to_tuple(address)
                if row not in number_rows:
                    boundaries.add(row)
        for row, col in coordinates:
            if any(
                re.match(r"^(?:Total\b|All\b)", label, re.IGNORECASE)
                for label in labels_before(sheet, row, col, row_labels)
            ):
                children = any(
                    other_col == col
                    and other > row
                    and (
                        not sheet.get("tables")
                        or cell_region(sheet, row, col)
                        == cell_region(sheet, other, col)
                    )
                    and not any(
                        re.match(r"^(?:Total\b|All\b)", label, re.IGNORECASE)
                        for label in labels_before(sheet, other, col, row_labels)
                    )
                    and not any(row < boundary < other for boundary in boundaries)
                    for other, other_col in coordinates
                )
                if children:
                    return [
                        "Across-all aggregation reads both a published Total/All parent and rows within its group. Use the matching published total directly or only disjoint children; do not sum both."
                    ]
    return []


def age_interval(label: str) -> tuple[int, float] | None:
    """Parse labelled age bands only; identifiers and hour categories are not ages."""
    if not re.search(r"\byears?\b", label, re.IGNORECASE):
        return None
    bounded = re.search(
        r"\b(\d+)\s*(?:to|[-–])\s*(\d+)\s*years?\b", label, re.IGNORECASE
    )
    if bounded:
        return int(bounded[1]), float(bounded[2])
    open_ended = re.search(
        r"\b(\d+)\s*years?\s*(?:and|or)\s*(?:over|older|more)\b", label, re.IGNORECASE
    )
    return (int(open_ended[1]), float("inf")) if open_ended else None


def mean_scope_cells(sheet: dict[str, Any], row: int, query: str) -> list[str] | None:
    """Only infer a mean's columns inside one evidenced table/header branch."""
    labels = [
        (coordinate_to_tuple(address)[1], canonical_label(entry["value"]))
        for address, entry in sheet["cells"].items()
        if coordinate_to_tuple(address)[0] == row
        and entry["kind"] == "string"
        and entry["value"]
        and canonical_label(entry["value"]).casefold() in query.casefold()
    ]
    if len(labels) != 1:
        return None
    label_col = labels[0][0]
    regions = [
        table
        for table in sheet.get("tables", [])
        if (bounds := range_boundaries(table["range"]))[0] <= label_col <= bounds[2]
        and bounds[1] <= row <= bounds[3]
    ]
    if sheet.get("tables") and len(regions) != 1:
        return None
    region = regions[0] if regions else None
    bounds = range_boundaries(region["range"]) if region else None
    headers = (region.get("headers") if region else None) or sheet.get("headers", {})
    available = [
        address
        for address, entry in sheet["cells"].items()
        if entry["kind"] == "number"
        and (position := coordinate_to_tuple(address))[0] == row
        and position[1] > label_col
        and (bounds is None or bounds[0] <= position[1] <= bounds[2])
    ]
    if not available:
        return None
    paths = {
        address: headers.get(get_column_letter(coordinate_to_tuple(address)[1]), [])
        for address in available
    }
    # Unlabelled columns cannot establish that every measure belongs in the mean.
    if any(not path for path in paths.values()):
        return None
    years = set(re.findall(r"\b(?:19|20)\d{2}\b", query))
    if years:
        available = [
            address
            for address in available
            if years & set(re.findall(r"\b(?:19|20)\d{2}\b", " ".join(paths[address])))
        ]
        if not available:
            return None
    # A named header branch constrains columns; a year alone is not such a branch.
    matched = []
    for address in available:
        for label in paths[address]:
            text = re.sub(r"\(\d+\)", "", canonical_label(label)).strip()
            if (
                not re.fullmatch(r"(?:19|20)\d{2}", text)
                and len(text) >= 3
                and re.search(rf"(?<!\w){re.escape(text)}(?!\w)", query, re.IGNORECASE)
            ):
                matched.append(address)
                break
    if matched:
        available = matched
    # Mixed measures and identity/weight columns need explicit semantic selection.
    if any(
        re.search(
            r"\b(?:id|identifier|code|weight|denominator)\b|sample size",
            " ".join(paths[address]),
            re.IGNORECASE,
        )
        and not re.search(
            r"\b(?:id|identifier|code|weight|denominator)\b|sample size",
            query,
            re.IGNORECASE,
        )
        for address in available
    ):
        return None
    # Competing multi-column header branches must be resolved by the model, not
    # automatically merged just because they share a metric row.
    first_labels = {
        paths[address][0] for address in available if len(paths[address]) > 1
    }
    if len(first_labels) > 1 and not years and not matched:
        return None
    return sorted(available, key=coordinate_to_tuple)


def complete_mean_contract(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> str | None:
    """Materialize an unambiguous ALL-column mean on a model-selected metric row."""
    if not isinstance(execution.result, (int, float)) or isinstance(
        execution.result, bool
    ):
        return None
    if not re.search(
        r"\b(?:average|mean)\b.*\bacross all\b", query, re.IGNORECASE
    ) or re.search(
        r"\b(?:leaf|mutually exclusive|weighted|highest|lowest|rank)\b",
        query,
        re.IGNORECASE,
    ):
        return None
    import json

    candidates = []
    for name, sheet in workbook.items():
        selected_rows = {
            coordinate_to_tuple(key[len(name) + 1 :])[0]
            for key, entry in execution.reads.items()
            if key.startswith(name + "!") and entry["kind"] == "number"
        }
        for row in selected_rows:
            matching_label = any(
                entry["kind"] == "string"
                and entry["value"]
                and coordinate_to_tuple(address)[0] == row
                and canonical_label(entry["value"]).casefold() in query.casefold()
                for address, entry in sheet["cells"].items()
            )
            if not matching_label:
                continue
            available = mean_scope_cells(sheet, row, query)
            observed = {
                key[len(name) + 1 :]
                for key, entry in execution.reads.items()
                if key.startswith(name + "!") and entry["kind"] == "number"
            }
            # Eager reads do not prove that every value was used: a program may
            # read the complete row and then average a leaf-only subset.
            plain_mean = (
                available
                and re.match(
                    r"\s*(?:what (?:is|was) (?:the )?|(?:calculate|compute|find) (?:the )?)?(?:average|mean)\b",
                    query,
                    re.IGNORECASE,
                )
                and not re.search(
                    r"\b(?:difference|subtract|minus|divide|ratio|convert|change|increase|decrease)\b|\bas (?:a )?(?:percentage|percent|fraction|proportion)\b|\b(?:in|to)\s+(?:USD|EUR|dollars?|units?|thousands?|millions?|basis points)\b",
                    query,
                    re.IGNORECASE,
                )
                and not any(
                    "%" in sheet["cells"][address].get("number_format", "")
                    for address in available
                )
            )
            mismatch = bool(plain_mean) and format_answer(
                execution.result, query
            ) != format_answer(
                math.fsum(sheet["cells"][address]["value"] for address in available)
                / len(available),
                query,
            )
            if available and (set(available) - observed or mismatch):
                candidates.append((name, available))
    if len(candidates) != 1:
        return None
    name, addresses = candidates[0]
    return f"import statistics\nvalues_to_average=[num({json.dumps(name)}, address) for address in {addresses!r}]\nresult=statistics.mean(values_to_average)"


def row_context_dimensions(
    sheet: dict[str, Any], matches: list[int]
) -> dict[int, dict[int, str]]:
    """Retain source columns so alternatives are not flattened into joint qualifiers."""
    dimensions: dict[int, dict[int, str]] = {}
    matched_rows = set(matches)
    for address, entry in sheet["cells"].items():
        position, column = coordinate_to_tuple(address)
        if position not in matched_rows:
            continue
        text = canonical_label(entry["value"]).casefold()
        if (
            entry["kind"] == "string"
            and len(text) >= 2
            and text
            not in {
                "of",
                "at",
                "in",
                "on",
                "an",
                "as",
                "is",
                "to",
                "or",
                "and",
                "the",
                "for",
            }
        ):
            dimensions.setdefault(position, {})[column] = text
        elif entry["kind"] == "number" and re.fullmatch(r"\d{4}", text):
            path = source_headers(sheet, address).get(get_column_letter(column), [])
            if any(
                re.search(r"\b(?:year|period)\b", value, re.IGNORECASE)
                for value in path
            ):
                dimensions.setdefault(position, {})[column] = text
    return dimensions


def row_context_features(
    sheet: dict[str, Any], matches: list[int], label: str
) -> dict[int, set[str]]:
    """Index row dimensions once per repeated label, not once per numeric read."""
    return {
        row: {text for text in columns.values() if text != label.casefold()}
        for row, columns in row_context_dimensions(sheet, matches).items()
    }


def flat_record_qualifiers_match(
    dimensions: dict[int, dict[int, str]], selected: set[int], label: str, query: str
) -> bool:
    """Alternatives within one column are OR; distinct source columns remain AND."""
    allowed: dict[int, set[str]] = {}
    for columns in dimensions.values():
        for column, text in columns.items():
            if re.search(rf"(?<!\w){re.escape(text)}(?!\w)", query, re.IGNORECASE):
                allowed.setdefault(column, set()).add(text)
    # The repeated label identifies the rows being reviewed, not an additional
    # filter in every column where that same label can occur.
    qualifiers = {
        column: values
        for column, values in allowed.items()
        if values - {label.casefold()}
    }
    return all(
        all(
            dimensions.get(row, {}).get(column) in values
            for column, values in qualifiers.items()
        )
        for row in selected
    )


def row_context_resolves_label(
    features: dict[int, set[str]], row: int, matches: list[int], query: str
) -> bool:
    """Only a unique row supported by explicit question qualifiers resolves scope."""
    named = {
        text
        for text in features.get(row, set())
        if re.search(rf"(?<!\w){re.escape(text)}(?!\w)", query, re.IGNORECASE)
    }
    return bool(named) and {
        other for other in matches if named <= features.get(other, set())
    } == {row}


def restricted_metric_risks(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """Review unrequested restricted children per record, not just across the sheet."""

    def words(text: str) -> set[str]:
        return set(re.findall(r"[a-z]+", text.casefold()))

    quoted = {
        canonical_label(text).casefold()
        for text in re.findall(r'["“`]([^"”`]+)["”`]', query)
    }
    if not quoted:
        return []
    query_words = words(query)
    generic = {
        "the",
        "of",
        "for",
        "at",
        "all",
        "total",
        "overall",
        "persons",
        "people",
        "who",
        "usually",
    }
    risks: list[str] = []
    for name, sheet in workbook.items():
        addresses = [
            key.rsplit("!", 1)[1]
            for key, entry in execution.reads.items()
            if key.rsplit("!", 1)[0] == name and entry["kind"] == "number"
        ]
        observed = {
            get_column_letter(coordinate_to_tuple(address)[1]) for address in addresses
        }
        # A vertical subgroup can have only a local row-label heading. Retain
        # inherited numeric column paths for this soft review signal; explicit
        # local column definitions still override the sheet paths.
        headers = {**sheet.get("headers", {}), **read_header_paths(sheet, addresses)}
        branches: dict[tuple[str, ...], dict[str, str]] = {}
        for column, path in headers.items():
            if len(path) >= 2 and canonical_label(path[-2]).casefold() in quoted:
                branches.setdefault(tuple(path[:-1]), {})[column] = path[-1]
        for parent, children in branches.items():
            overall = {
                column
                for column, caption in children.items()
                if re.match(
                    r"^(?:total|all|overall)\b", canonical_label(caption), re.IGNORECASE
                )
            }
            selected = observed & children.keys()
            if len(overall) != 1 or not selected:
                continue
            by_row: dict[int, set[str]] = {}
            for address in addresses:
                row, column = coordinate_to_tuple(address)
                by_row.setdefault(row, set()).add(get_column_letter(column))
            restricted_rows = {
                row: sorted(columns & (children.keys() - overall))
                for row, columns in by_row.items()
                if columns & (children.keys() - overall) and not columns & overall
            }
            if not restricted_rows:
                continue
            common_words = (
                generic | words(" ".join(parent)) | words(children[next(iter(overall))])
            )
            if any(
                (words(children[column]) - common_words) & query_words
                for column in selected
            ):
                continue  # A named restricted population may intentionally override the overall column.
            risks.append(
                f"{name}: quoted parent metric {parent[-1]!r} has overall column {sorted(overall)} "
                f"and restricted children; rows {restricted_rows} read restricted columns without that record's overall column. Independently verify "
                "whether the question requests the overall population or that restricted subgroup; "
                "shared parent captions do not make their child columns interchangeable."
            )
    return risks


def flat_string_projection_risks(
    workbook: dict[str, Any], execution: ExecutionResult, query: str, tree: ast.Module
) -> list[str]:
    """Review character projection on a flat workbook vector before joins/filtering."""
    if re.search(
        r"\b(?:initials?|acronym|prefix|characters?|letters?)\b|\b(?:starts?|begins?)\s+with\b",
        query,
        re.IGNORECASE,
    ):
        return []
    if any(
        isinstance(node, ast.FunctionDef)
        and node.name == "values"
        or isinstance(node, ast.Name)
        and node.id == "values"
        and isinstance(node.ctx, ast.Store)
        for node in ast.walk(tree)
    ):
        return []  # A shadowed helper has no known return-shape contract.
    assignments = {
        target.id: statement.value
        for statement in tree.body
        if isinstance(statement, ast.Assign)
        for target in statement.targets
        if isinstance(target, ast.Name)
    }

    def resolve(node: ast.AST) -> ast.AST:
        seen: set[str] = set()
        while (
            isinstance(node, ast.Name)
            and node.id in assignments
            and node.id not in seen
        ):
            seen.add(node.id)
            node = assignments[node.id]
        return node

    for comprehension in ast.walk(tree):
        if not isinstance(
            comprehension, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)
        ):
            continue
        for generator in comprehension.generators:
            source = resolve(generator.iter)
            if (
                not isinstance(generator.target, ast.Name)
                or not isinstance(source, ast.Call)
                or not isinstance(source.func, ast.Name)
                or source.func.id != "values"
                or len(source.args) != 2
            ):
                continue
            projections = [
                node
                for node in ast.walk(comprehension)
                if isinstance(node, ast.Subscript)
                and isinstance(node.value, ast.Name)
                and node.value.id == generator.target.id
                and isinstance(node.slice, ast.Constant)
                and type(node.slice.value) is int
                and node.slice.value == 0
            ]
            if not projections:
                continue
            try:
                name = ast.literal_eval(resolve(source.args[0]))
                area = ast.literal_eval(resolve(source.args[1]))
            except (ValueError, TypeError):
                continue
            if (
                not isinstance(name, str)
                or name not in workbook
                or not isinstance(area, str)
            ):
                continue
            left, top, right, bottom = range_boundaries(area)
            if None in (left, top, right, bottom):
                continue
            if any(
                entry["kind"] == "string"
                and len(str(entry["value"])) > 1
                and (position := coordinate_to_tuple(address))[0]
                in range(top, bottom + 1)
                and left <= position[1] <= right
                and f"{name}!{address}" in execution.reads
                for address, entry in workbook[name]["cells"].items()
            ):
                return [
                    "Flat values() string projection: each element is already a scalar, so element[0] takes only its first character. Verify that full workbook labels survive joins/filtering; use the scalar directly unless character extraction is explicitly requested. An empty match followed by zero is not proof of correct scope."
                ]
    return []


def header_domain_risks(
    workbook: dict[str, Any], execution: ExecutionResult, query: str, tree: ast.Module
) -> list[str]:
    """Review categorical header reads even when a caller supplied explicit bounds."""
    if any(
        isinstance(node, ast.FunctionDef)
        and node.name == "data_rows"
        or isinstance(node, ast.Name)
        and node.id == "data_rows"
        and isinstance(node.ctx, ast.Store)
        for node in ast.walk(tree)
    ):
        return []
    if not (
        execution.result in (0, "")
        or re.search(
            r"\b(?:every|each|all|required|qualif\w*|cover\w*)\b", query, re.IGNORECASE
        )
    ):
        return []
    if re.search(
        r"\b(?:including|include|count)\b[^.?!]{0,20}\bheaders?\b", query, re.IGNORECASE
    ):
        return []
    suspects: set[str] = set()
    unverified: set[str] = set()
    for call in ast.walk(tree):
        if (
            not isinstance(call, ast.Call)
            or not isinstance(call.func, ast.Name)
            or call.func.id != "data_rows"
            or len(call.args) < 2
        ):
            continue
        try:
            name = ast.literal_eval(call.args[0])
            columns = ast.literal_eval(call.args[1])
        except (ValueError, TypeError):
            continue
        if (
            not isinstance(name, str)
            or name not in workbook
            or not isinstance(columns, dict)
            or not columns
            or any(kind != "string" for kind in columns.values())
            or not all(isinstance(col, str) for col in columns)
        ):
            continue
        requested = {col.upper() for col in columns}
        sheet = workbook[name]
        first_text_row = None
        if not sheet.get("headers") and all(
            item["kind"] in {"string", "blank"} for item in sheet["cells"].values()
        ):
            first_text_row = min(
                (coordinate_to_tuple(item)[0] for item in sheet["cells"]), default=None
            )
        for key, entry in execution.reads.items():
            if key.rsplit("!", 1)[0] != name or entry["kind"] != "string":
                continue
            address = key.rsplit("!", 1)[1]
            row, column = coordinate_to_tuple(address)
            letter = get_column_letter(column)
            if letter not in requested:
                continue
            region = cell_region(sheet, row, column)
            if region is None and not sheet.get("headers"):
                # All-text sheets intentionally have no asserted parser schema.
                # Only request review when the first observed string also names
                # a field in the question; never silently discard that row.
                caption = canonical_label(entry["value"]).casefold()
                pattern = (
                    re.escape(caption[:-1]) + r"(?:y|ies)"
                    if caption.endswith("y")
                    else re.escape(caption) + r"s?"
                )
                if (
                    row == first_text_row
                    and len(caption) >= 3
                    and re.search(rf"(?<!\w){pattern}(?!\w)", query, re.IGNORECASE)
                ):
                    unverified.add(key)
                continue
            if not region or row != range_boundaries(region["range"])[1]:
                continue
            bounds = range_boundaries(region["range"])
            if any(
                (position := coordinate_to_tuple(other))[0] == row
                and bounds[0] <= position[1] <= bounds[2]
                and item["kind"] not in {"string", "blank"}
                for other, item in sheet["cells"].items()
            ):
                continue  # A data-bearing first row is not merely a caption.
            path = region.get("headers", {}).get(letter, [])
            if (
                path
                and canonical_label(entry["value"]).casefold()
                == canonical_label(path[-1]).casefold()
            ):
                suspects.add(key)
    if not suspects and not unverified:
        return []
    if unverified and not suspects:
        return [
            (
                f"String-only data_rows includes first-row cells {sorted(unverified)[:8]} whose text also names a field in the question. "
                "This all-text sheet has NO verified header schema: inspect the original first row to decide whether it is a heading or a genuine record. "
                "Keep it if it is data; if it is a heading, use observed data bounds. Do not assume every string is a data record, or delete a first record merely because it is first."
            )
        ]
    return [
        (
            f"String-only data_rows includes probable heading cells {sorted(suspects)[:8]}. "
            "Verify whether these captions entered a record/category universe, required set, join or count. "
            "If they are headings, use observed inclusive data start/end bounds and preserve valid missing-measure records. "
            "A header can make every/coverage conditions impossible and silently yield an empty answer or fallback number. "
            "Header reads used only for schema discovery can be legitimate; verify actual use rather than deleting data blindly."
        )
    ]


def named_row_scope_risks(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> list[str]:
    """Flag an omitted, uniquely named record in a table actually used numerically."""
    risks = []
    for name, sheet in workbook.items():
        numeric_rows = {
            coordinate_to_tuple(address)[0]
            for address, entry in sheet["cells"].items()
            if entry["kind"] == "number"
        }
        labels: dict[str, list[tuple[int, int]]] = {}
        for row, entries in row_label_index(sheet).items():
            if row not in numeric_rows:
                continue
            for column, label in entries:
                if len(re.findall(r"[^\W\d_]", label)) >= 2:
                    labels.setdefault(label.casefold(), []).append((row, column))
        actual = {
            key.rsplit("!", 1)[1]: entry
            for key, entry in execution.reads.items()
            if key.rsplit("!", 1)[0] == name
            and entry["kind"] not in {"type_probe", "lookup_probe"}
        }
        if not actual:
            continue
        read_rows = {coordinate_to_tuple(address)[0] for address in actual}
        for label, positions in labels.items():
            if len(positions) != 1 or not re.search(
                rf"(?<!\w){re.escape(label)}(?!\w)", query, re.IGNORECASE
            ):
                continue
            row, column = positions[0]
            if row in read_rows:
                continue
            table = cell_region(sheet, row, column)
            if table is None:
                continue
            peers = {
                other_label
                for other_label, places in labels.items()
                if len(places) == 1
                and places[0][1] == column
                and cell_region(sheet, *places[0]) == table
            }
            if len(peers) < 2:
                continue
            numeric_reads = [
                address
                for address, entry in actual.items()
                if entry["kind"] == "number"
                and cell_region(sheet, *coordinate_to_tuple(address)) == table
            ]
            if numeric_reads:
                risks.append(
                    f"{name}: question names unique record {label!r} at row {row}, "
                    "but the program reads numeric data from other rows of this table "
                    "without reading that record. Verify the identity column and joins; "
                    "do not substitute the first data row."
                )
    return risks


def scope_risks(
    workbook: dict[str, Any], execution: ExecutionResult, query: str, code: str = ""
) -> list[str]:
    """Application-triggered review for ambiguity, rather than model confidence."""
    risks = restricted_metric_risks(workbook, execution, query)
    risks += named_row_scope_risks(workbook, execution, query)
    tree = ast.parse(code) if code else None
    if tree is not None:
        risks += flat_string_projection_risks(workbook, execution, query, tree)
        risks += header_domain_risks(workbook, execution, query, tree)
    declared_arithmetic = bool(
        re.search(
            r"\badd(?:s|ing)?\b[\s\S]*\bsubtract(?:s|ing)?\b", query, re.IGNORECASE
        )
    )
    aggregate_program = bool(
        tree is not None
        and any(
            isinstance(node, ast.AugAssign)
            and isinstance(node.op, (ast.Add, ast.Mult))
            or isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in {"sum", "len", "mean", "fmean"}
            for node in ast.walk(tree)
        )
    )
    numeric_sources = {
        key.rsplit("!", 1)[0]
        for key, entry in execution.reads.items()
        if entry["kind"] == "number"
    }
    rank_subtractions = []
    if tree is not None:
        parents = {
            child: parent
            for parent in ast.walk(tree)
            for child in ast.iter_child_nodes(parent)
        }
        for node in ast.walk(tree):
            if not isinstance(node, ast.BinOp) or not isinstance(node.op, ast.Sub):
                continue
            absolute = parents.get(node)
            comparison = parents.get(absolute)
            if (
                isinstance(absolute, ast.Call)
                and isinstance(absolute.func, ast.Name)
                and absolute.func.id == "abs"
                and absolute.args == [node]
                and isinstance(comparison, ast.Compare)
                and comparison.left is absolute
                and len(comparison.ops) == 1
                and isinstance(comparison.ops[0], (ast.Lt, ast.LtE, ast.Eq))
                and isinstance((tolerance := comparison.comparators[0]), ast.Constant)
                and type(tolerance.value) in {int, float}
                and 0 <= tolerance.value <= 1e-6
            ):
                continue  # Symmetric equality tolerance is not a signed ranking objective.
            rank_subtractions.append(node)
    if (
        len(numeric_sources) > 1
        and isinstance(execution.result, str)
        and re.search(
            r"\b(?:which|who)\b.*\b(?:largest|highest|lowest|most|least|maximum|minimum)\b",
            query,
            re.IGNORECASE,
        )
        and not declared_arithmetic
        and tree is not None
        and any(
            isinstance(node, ast.BinOp)
            and isinstance(node.op, ast.Sub)
            and not isinstance(node.left, ast.Constant)
            and not isinstance(node.right, ast.Constant)
            for node in rank_subtractions
        )
    ):
        risks.append(
            "Cross-sheet derived rank: independently check subtraction direction, entity joins, aggregation and ties against the question. A rank over a reversed difference can run successfully and still select the wrong entity."
        )
    for name, sheet in workbook.items():
        selected_rows = {
            coordinate_to_tuple(key[len(name) + 1 :])[0]
            for key, entry in execution.reads.items()
            if key.startswith(name + "!") and entry["kind"] == "number"
        }
        targets: dict[str, set[int]] = {}
        row_labels = row_label_index(sheet)
        for row, labels_in_row in row_labels.items():
            for _, label in labels_in_row:
                if re.search(
                    rf"\bfor\s+(?:the\s+)?{re.escape(label)}\s+only\b",
                    query,
                    re.IGNORECASE,
                ):
                    targets.setdefault(label, set()).add(row)
        for label, matching in targets.items():
            if selected_rows and selected_rows - matching:
                risks.append(
                    f"{name}: question is explicitly restricted to {label!r}, but numeric reads include other rows; independently verify filtering and joins rather than summing all entities."
                )
        if re.search(
            r"\b(?:average|mean)\b.*\bacross all\b", query, re.IGNORECASE
        ) and any(mean_scope_cells(sheet, row, query) is None for row in selected_rows):
            risks.append(
                f"{name}: the mean's table/header branch is not uniquely evidenced; check measures, years, identities and weights."
            )
        labels: dict[str, list[int]] = {}
        context_rows: list[tuple[int, str]] = []
        by_row: dict[int, list[dict[str, Any]]] = {}
        for address, entry in sheet["cells"].items():
            row, _ = coordinate_to_tuple(address)
            by_row.setdefault(row, []).append(entry)
            if entry["kind"] == "string" and entry["value"]:
                label = canonical_label(entry["value"])
                if re.search(rf"(?<!\w){re.escape(label)}(?!\w)", query, re.IGNORECASE):
                    labels.setdefault(label, []).append(row)
        for row, entries in by_row.items():
            text = [
                canonical_label(e["value"])
                for e in entries
                if e["kind"] == "string" and e["value"]
            ]
            if len(text) == 1 and not any(
                e["kind"] in {"number", "datetime"} for e in entries
            ):
                context_rows.append((row, text[0]))
        for label, matches in labels.items():
            if len(set(matches)) <= 1 or not selected_rows.intersection(matches):
                continue
            justified = True
            features = row_context_features(sheet, matches, label)
            regions = {
                region["range"]
                if (
                    region := cell_region(
                        sheet,
                        row,
                        min((col for col, _ in row_labels.get(row, [])), default=1),
                    )
                )
                else None
                for row in matches
            }
            contexts = {
                next(
                    (
                        text
                        for before, text in sorted(context_rows, reverse=True)
                        if before < row
                    ),
                    "",
                )
                for row in matches
            }
            role_columns = {
                column
                for row in matches
                for column, text in row_labels.get(row, [])
                if text.casefold() == label.casefold()
            }
            if (
                len(role_columns) >= 2
                and set(matches) <= selected_rows
                and len(regions) == len(contexts) == 1
                and None not in regions
            ):
                region = next(
                    table for table in sheet["tables"] if table["range"] in regions
                )
                paths = [
                    tuple(region.get("headers", {}).get(get_column_letter(column), []))
                    for column in role_columns
                ]
                if (
                    all(paths)
                    and len(set(paths)) == len(paths)
                    and all(
                        cell_region(sheet, *coordinate_to_tuple(key.rsplit("!", 1)[1]))
                        == region
                        for key, entry in execution.reads.items()
                        if key.rsplit("!", 1)[0] == name and entry["kind"] == "number"
                    )
                ):
                    # A fully read relation can repeat an entity in distinct
                    # column roles. That alone is not evidence of several sections.
                    continue
            if (
                aggregate_program
                or re.search(
                    r"\b(?:sum|summed|total|combined|aggregate)\b", query, re.IGNORECASE
                )
            ) and (
                len(regions) == 1
                and None not in regions
                and len(contexts) == 1
                and flat_record_qualifiers_match(
                    row_context_dimensions(sheet, matches),
                    selected_rows.intersection(matches),
                    label,
                    query,
                )
            ):
                # Repeated dimension values in one flat ledger are records to
                # aggregate, not separate sections requiring another model call.
                continue
            specific_context = any(
                not re.fullmatch(r"(?:Total|All)", text, re.IGNORECASE)
                and re.search(rf"(?<!\w){re.escape(text)}(?!\w)", query, re.IGNORECASE)
                for _, text in context_rows
            )
            for row in selected_rows.intersection(matches):
                if row_context_resolves_label(features, row, matches, query):
                    continue
                prior = [text for before, text in sorted(context_rows) if before < row]
                context = prior[-1] if prior else ""
                if (
                    re.fullmatch(r"(?:Total|All)", context, re.IGNORECASE)
                    and not specific_context
                ):
                    # An explicit overall section is evidence for an unqualified
                    # question; repeated labels in subgroups alone need no extra call.
                    continue
                words = re.findall(r"\w+", context)
                prefix = " ".join(words[:2]) if len(words) >= 2 else context
                if not prefix or not re.search(
                    rf"(?<!\w){re.escape(prefix)}(?!\w)", query, re.IGNORECASE
                ):
                    justified = False
                    break
            if not justified:
                risks.append(
                    f"{name}: label {label!r} occurs in several sections; independently verify table, group and year."
                )
                break
    return risks


def evidence_errors(
    workbook: dict[str, Any], reads: dict[str, Any], selections: list[dict[str, Any]]
) -> list[str]:
    """Validate claimed source regions against observed reads, not reference answers."""
    if not selections:
        return []
    areas: dict[str, list[tuple[int, int, int, int]]] = {}
    for selection in selections:
        name, area = selection["sheet"], selection["range"]
        if name not in workbook:
            return [f"Evidence sheet {name!r} does not exist"]
        if not re.fullmatch(r"[A-Z]+[1-9]\d*(?::[A-Z]+[1-9]\d*)?", area):
            return ["Evidence needs an explicit Excel cell/range"]
        bounds = range_boundaries(area)
        if bounds[0] > bounds[2] or bounds[1] > bounds[3]:
            return ["Evidence range is reversed"]
        areas.setdefault(name, []).append(bounds)
    for key, entry in reads.items():
        if entry["kind"] in {"type_probe", "lookup_probe"}:
            continue
        # Sheet names can contain !; the final delimiter precedes the address.
        name, address = key.rsplit("!", 1)
        row, col = coordinate_to_tuple(address)
        if not any(
            left <= col <= right and top <= row <= bottom
            for left, top, right, bottom in areas.get(name, [])
        ):
            return [
                f"Read {key} lies outside the declared evidence; include all input/header regions"
            ]
    return []


def complete_total_contract(
    workbook: dict[str, Any], execution: ExecutionResult, query: str
) -> str | None:
    """Use the sole selected published parent for an across-all total contract."""
    if re.search(
        r"\b(?:leaf|leaves)\b|\b(?:exclude|excluding|ignore)\b[^.?!]{0,40}\b(?:total|parent)s?\b",
        query,
        re.IGNORECASE,
    ):
        return None
    overlap = aggregation_overlap_errors(workbook, execution.reads, query)
    if not overlap or re.search(r"\b\d+\s*(?:to|[-–])\s*\d+\b", query):
        return None
    candidates = []
    for name, sheet in workbook.items():
        row_labels = row_label_index(sheet)
        selected = [
            key[len(name) + 1 :]
            for key, entry in execution.reads.items()
            if key.startswith(name + "!") and entry["kind"] == "number"
        ]
        # An omitted parent is recoverable only inside the same evidenced table
        # and single measure column, for an explicit all-age aggregation.
        addresses = selected
        if re.search(r"\ball age groups\b|\bacross all ages\b", query, re.IGNORECASE):
            positions = [coordinate_to_tuple(address) for address in selected]
            regions = {
                region["range"] if (region := cell_region(sheet, row, col)) else None
                for row, col in positions
            }
            columns = {col for _, col in positions}
            if len(columns) == 1 and len(regions) == 1 and None not in regions:
                column = next(iter(columns))
                region = cell_region(sheet, *positions[0])
                addresses = [
                    address
                    for address, entry in sheet["cells"].items()
                    if entry["kind"] == "number"
                    and coordinate_to_tuple(address)[1] == column
                    and cell_region(sheet, *coordinate_to_tuple(address)) == region
                ]
        for address in addresses:
            row, col = coordinate_to_tuple(address)
            if any(
                re.match(
                    r"^(?:Total\b|All\b)",
                    text,
                    re.IGNORECASE,
                )
                for text in labels_before(sheet, row, col, row_labels)
            ):
                candidates.append((name, address))
    if len(candidates) != 1:
        return None
    name, address = candidates[0]
    return f"result=num({name!r}, {address!r})"
